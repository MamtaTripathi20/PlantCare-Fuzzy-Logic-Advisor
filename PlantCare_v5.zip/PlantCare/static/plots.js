(() => {
  const $ = id => document.getElementById(id);
  let reading = null;

  function showCompare(j) {
    const rows = [];
    if (j.reading) {
      const f = j.reading.fuzzy, c = j.reading.crisp;
      rows.push(`<div class="rule"><div>Your reading<small>Fuzzy: ${f.level} · If-else: ${c.level}</small></div><strong>${f.score.toFixed(0)} vs ${c.score}</strong></div>`);
    }
    const m = j.max_step;
    rows.push(`<div class="rule"><div>Largest output jump per 0.5°C step<small>Smaller means a smoother, more gradual controller</small></div><strong>Fuzzy ${m.fuzzy} · If-else ${m.crisp}</strong></div>`);
    $("cmp").innerHTML = rows.join("");
  }

  function render() {
    const plant = $("plant").value, q = new URLSearchParams();
    if (reading) {
      q.set("t", reading.temp); q.set("h", reading.hum);
      if (reading.leaf) q.set("d", reading.leaf.damage);
    }
    const qs = q.toString() ? "?" + q : "";
    $("imgMf").src = `/plots/${plant}/mf.png${qs}`;
    $("imgSurf").src = `/plots/${plant}/surface.png${qs}`;
    $("imgCmp").src = `/plots/${plant}/compare.png${qs}`;
    fetch(`/api/compare?plant=${plant}&${q}`).then(r => r.json()).then(showCompare).catch(() => {});
  }

  window.onResult = r => { reading = {temp: r.temp, hum: r.hum, leaf: r.leaf}; render(); };
  $("plant").addEventListener("change", render);
  render();
})();
