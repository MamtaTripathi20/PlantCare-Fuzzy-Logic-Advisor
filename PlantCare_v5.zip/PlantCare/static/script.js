const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"]/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"}[c]));
const bars = o => `<div class="membership-list">${Object.entries(o).map(([k, v]) =>
  `<div class="membership-row"><span>${k}</span><div class="bar"><i style="width:${v * 100}%"></i></div><strong>${v.toFixed(2)}</strong></div>`).join("")}</div>`;

$("photo").addEventListener("change", e => {
  const f = e.target.files[0];
  $("preview").hidden = !f;
  if (f) $("preview").src = URL.createObjectURL(f);
});

function show(r) {
  $("empty").hidden = true; $("result").hidden = false;
  $("risk").textContent = r.overall.score.toFixed(0);
  $("level").textContent = r.overall.level + " risk"; $("level").className = "category " + r.overall.level;
  $("meterFill").style.width = r.overall.score + "%";
  $("climate").textContent = `${r.plant}: climate stress is ${r.climate.level.toLowerCase()} (${r.climate.score.toFixed(0)}/100).`;
  $("src").textContent = r.conditions.source;
  $("readings").textContent = `${r.temp.toFixed(1)}°C · ${Math.round(r.hum)}%`;
  const l = r.leaf;
  $("photoInfo").textContent = l ? `Photo: ${l.damage}% of leaf-coloured pixels are yellow or brown (green ${l.green}%, yellow ${l.yellow}%, brown ${l.brown}%).`
    : "No photo added, so the rating uses temperature and humidity only.";
  const w = r.why;
  $("whySummary").textContent = w.summary;
  $("whyFactors").innerHTML = w.factors.map(f => `<div class="rule"><div>${esc(f.text)}<small>${esc(f.name)}</small></div><strong class="${f.ok ? "okc" : "badc"}">${f.ok ? "OK" : "OUT OF RANGE"}</strong></div>`).join("");
  $("whyHow").textContent = w.how;
  $("members").innerHTML = Object.entries(r.degrees).map(([n, o]) => `<p class="group">${n}</p>${bars(o)}`).join("");
  $("rules").innerHTML = r.rules.map(x => `<div class="rule"><div>${esc(x.if)}<small>THEN ${esc(x.then)}</small></div><strong>S${x.stage} · ${(x.strength * 100).toFixed(0)}%</strong></div>`).join("");
  $("care").innerHTML = r.care.map(c => `<div class="rule"><div>${esc(c.text)}<small>${c.urgency === "now" ? "Do now" : "Keep an eye on it"}</small></div></div>`).join("");
  $("notes").innerHTML = "<span>✿</span> " + r.notes.map(esc).join(" ");
  if (window.onResult) window.onResult(r);
}

$("form").addEventListener("submit", async e => {
  e.preventDefault();
  $("error").textContent = "";
  const btn = $("go"); btn.disabled = true; btn.textContent = "Analysing...";
  try {
    const res = await fetch("/api/analyze", {method: "POST", body: new FormData($("form"))});
    const r = await res.json();
    if (!res.ok) throw new Error(r.error || "Something went wrong.");
    show(r);
  } catch (err) {
    $("error").textContent = err.message;
  } finally {
    btn.disabled = false; btn.textContent = "Analyse my plant";
  }
});
