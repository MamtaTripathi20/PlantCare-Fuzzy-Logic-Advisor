"""Free, offline leaf-colour analysis: share of yellow/brown pixels among plant-coloured pixels."""
import numpy as np
from PIL import Image, UnidentifiedImageError


def leaf_damage(stream):
    try:
        img = Image.open(stream).convert("RGB")
    except (UnidentifiedImageError, OSError):
        raise ValueError("Could not read that image. Upload a JPG or PNG photo.")
    img.thumbnail((256, 256))
    hsv = np.asarray(img.convert("HSV"), dtype=float)
    h, s, v = hsv[..., 0] * 360 / 255, hsv[..., 1] / 255, hsv[..., 2] / 255
    colour = (s > .25) & (v > .15)
    green = colour & (h >= 70) & (h <= 170)
    yellow = colour & (h >= 38) & (h < 70)
    brown = colour & (h >= 10) & (h < 38) & (v < .6)
    g, y, b = (int(m.sum()) for m in (green, yellow, brown))
    leaf = g + y + b
    if leaf < .03 * h.size:
        raise ValueError("Not enough plant visible. Retake the photo closer, in good light, on a plain background.")
    return {"damage": round(100 * (y + b) / leaf, 1), "green": round(100 * g / leaf, 1),
            "yellow": round(100 * y / leaf, 1), "brown": round(100 * b / leaf, 1), "coverage": round(100 * leaf / h.size, 1)}
