"""Plain if-else controller used as a baseline for the fuzzy system.

Same plant profile, same rule table (R1), but hard thresholds instead of
overlapping fuzzy sets. Thresholds sit where the fuzzy memberships cross 0.5.
"""
from fuzzy_engine import PROFILES, R1

SCORE = {"Low": 15, "Moderate": 50, "High": 85}  # roughly the fuzzy centroids of each output set


def crisp_risk(plant, temp, hum):
    t0, t1, t2, t3 = PROFILES[plant]["temp"]
    h0, h1, h2, h3 = PROFILES[plant]["hum"]
    if temp < (t0 + t1) / 2:
        t = "Cold"
    elif temp > (t2 + t3) / 2:
        t = "Hot"
    else:
        t = "Ideal"
    if hum < (h0 + h1) / 2:
        h = "Dry"
    elif hum > (h2 + h3) / 2:
        h = "Humid"
    else:
        h = "Ideal"
    level = R1[(t, h)]
    return SCORE[level], level
