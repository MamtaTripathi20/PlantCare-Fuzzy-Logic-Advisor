import requests
from flask import Flask, render_template, request, jsonify
from fuzzy_engine import analyse, estimate_indoor, PROFILES, ENVS
from vision import leaf_damage
from plots import bp as plots_bp

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 6 * 1024 * 1024
app.register_blueprint(plots_bp)


def fail(msg, code=400):
    return jsonify({"error": msg}), code


@app.errorhandler(413)
def too_big(_):
    return fail("Photo is too large (max 6 MB).", 413)


CITY_DB = {  # name: (latitude, longitude, state). Built in so weather works without the geocoding search.
    'Agartala': (23.831, 91.286, 'Tripura'),
    'Agra': (27.177, 78.008, 'Uttar Pradesh'),
    'Ahmedabad': (23.023, 72.572, 'Gujarat'),
    'Aizawl': (23.727, 92.717, 'Mizoram'),
    'Ajmer': (26.45, 74.639, 'Rajasthan'),
    'Akola': (20.709, 77.003, 'Maharashtra'),
    'Alappuzha': (9.498, 76.339, 'Kerala'),
    'Aligarh': (27.897, 78.088, 'Uttar Pradesh'),
    'Amravati': (20.933, 77.752, 'Maharashtra'),
    'Amritsar': (31.634, 74.872, 'Punjab'),
    'Asansol': (23.683, 86.983, 'West Bengal'),
    'Aurangabad': (19.877, 75.343, 'Maharashtra'),
    'Bareilly': (28.367, 79.43, 'Uttar Pradesh'),
    'Belagavi': (15.85, 74.498, 'Karnataka'),
    'Bengaluru': (12.972, 77.594, 'Karnataka'),
    'Bhilai': (21.209, 81.379, 'Chhattisgarh'),
    'Bhopal': (23.26, 77.413, 'Madhya Pradesh'),
    'Bhubaneswar': (20.296, 85.825, 'Odisha'),
    'Bikaner': (28.022, 73.312, 'Rajasthan'),
    'Chandigarh': (30.733, 76.779, 'Chandigarh'),
    'Chennai': (13.083, 80.271, 'Tamil Nadu'),
    'Coimbatore': (11.017, 76.956, 'Tamil Nadu'),
    'Cuttack': (20.463, 85.883, 'Odisha'),
    'Dehradun': (30.316, 78.032, 'Uttarakhand'),
    'Delhi': (28.614, 77.209, 'Delhi'),
    'Dhanbad': (23.795, 86.43, 'Jharkhand'),
    'Durgapur': (23.552, 87.321, 'West Bengal'),
    'Faridabad': (28.409, 77.313, 'Haryana'),
    'Gangtok': (27.339, 88.612, 'Sikkim'),
    'Ghaziabad': (28.667, 77.449, 'Uttar Pradesh'),
    'Gorakhpur': (26.76, 83.373, 'Uttar Pradesh'),
    'Guntur': (16.307, 80.437, 'Andhra Pradesh'),
    'Gurugram': (28.459, 77.027, 'Haryana'),
    'Guwahati': (26.144, 91.736, 'Assam'),
    'Gwalior': (26.218, 78.182, 'Madhya Pradesh'),
    'Haridwar': (29.946, 78.164, 'Uttarakhand'),
    'Howrah': (22.589, 88.31, 'West Bengal'),
    'Hubballi': (15.364, 75.124, 'Karnataka'),
    'Hyderabad': (17.385, 78.487, 'Telangana'),
    'Imphal': (24.817, 93.937, 'Manipur'),
    'Indore': (22.72, 75.858, 'Madhya Pradesh'),
    'Itanagar': (27.084, 93.605, 'Arunachal Pradesh'),
    'Jabalpur': (23.182, 79.986, 'Madhya Pradesh'),
    'Jaipur': (26.912, 75.787, 'Rajasthan'),
    'Jalandhar': (31.326, 75.576, 'Punjab'),
    'Jalgaon': (21.007, 75.563, 'Maharashtra'),
    'Jammu': (32.727, 74.857, 'Jammu and Kashmir'),
    'Jamshedpur': (22.805, 86.203, 'Jharkhand'),
    'Jodhpur': (26.239, 73.024, 'Rajasthan'),
    'Kalyan': (19.243, 73.135, 'Maharashtra'),
    'Kanpur': (26.449, 80.332, 'Uttar Pradesh'),
    'Kochi': (9.931, 76.267, 'Kerala'),
    'Kohima': (25.667, 94.108, 'Nagaland'),
    'Kolhapur': (16.705, 74.243, 'Maharashtra'),
    'Kolkata': (22.573, 88.364, 'West Bengal'),
    'Kota': (25.213, 75.865, 'Rajasthan'),
    'Kozhikode': (11.259, 75.78, 'Kerala'),
    'Leh': (34.153, 77.577, 'Ladakh'),
    'Lonavala': (18.75, 73.407, 'Maharashtra'),
    'Lucknow': (26.847, 80.947, 'Uttar Pradesh'),
    'Ludhiana': (30.901, 75.857, 'Punjab'),
    'Madurai': (9.925, 78.12, 'Tamil Nadu'),
    'Mahabaleshwar': (17.923, 73.658, 'Maharashtra'),
    'Mangaluru': (12.914, 74.856, 'Karnataka'),
    'Meerut': (28.984, 77.706, 'Uttar Pradesh'),
    'Moradabad': (28.839, 78.777, 'Uttar Pradesh'),
    'Mumbai': (19.076, 72.878, 'Maharashtra'),
    'Mysuru': (12.296, 76.639, 'Karnataka'),
    'Nagpur': (21.146, 79.088, 'Maharashtra'),
    'Nanded': (19.138, 77.321, 'Maharashtra'),
    'Nashik': (19.998, 73.79, 'Maharashtra'),
    'Navi Mumbai': (19.033, 73.03, 'Maharashtra'),
    'Nellore': (14.443, 79.987, 'Andhra Pradesh'),
    'Noida': (28.535, 77.391, 'Uttar Pradesh'),
    'Ooty': (11.41, 76.695, 'Tamil Nadu'),
    'Panaji': (15.491, 73.828, 'Goa'),
    'Patna': (25.594, 85.138, 'Bihar'),
    'Pimpri-Chinchwad': (18.629, 73.8, 'Maharashtra'),
    'Prayagraj': (25.435, 81.846, 'Uttar Pradesh'),
    'Puducherry': (11.941, 79.808, 'Puducherry'),
    'Pune': (18.52, 73.857, 'Maharashtra'),
    'Raipur': (21.251, 81.63, 'Chhattisgarh'),
    'Rajkot': (22.304, 70.802, 'Gujarat'),
    'Ranchi': (23.344, 85.31, 'Jharkhand'),
    'Rishikesh': (30.087, 78.268, 'Uttarakhand'),
    'Rourkela': (22.26, 84.854, 'Odisha'),
    'Salem': (11.664, 78.146, 'Tamil Nadu'),
    'Sangli': (16.855, 74.564, 'Maharashtra'),
    'Satara': (17.68, 74.018, 'Maharashtra'),
    'Shillong': (25.578, 91.893, 'Meghalaya'),
    'Shimla': (31.105, 77.173, 'Himachal Pradesh'),
    'Siliguri': (26.727, 88.395, 'West Bengal'),
    'Solapur': (17.66, 75.906, 'Maharashtra'),
    'Srinagar': (34.084, 74.797, 'Jammu and Kashmir'),
    'Surat': (21.17, 72.831, 'Gujarat'),
    'Thane': (19.218, 72.978, 'Maharashtra'),
    'Thiruvananthapuram': (8.524, 76.936, 'Kerala'),
    'Thrissur': (10.527, 76.214, 'Kerala'),
    'Tiruchirappalli': (10.79, 78.705, 'Tamil Nadu'),
    'Tirupati': (13.629, 79.419, 'Andhra Pradesh'),
    'Udaipur': (24.585, 73.712, 'Rajasthan'),
    'Udupi': (13.341, 74.742, 'Karnataka'),
    'Ujjain': (23.179, 75.784, 'Madhya Pradesh'),
    'Vadodara': (22.307, 73.181, 'Gujarat'),
    'Varanasi': (25.318, 82.974, 'Uttar Pradesh'),
    'Vijayawada': (16.506, 80.648, 'Andhra Pradesh'),
    'Visakhapatnam': (17.687, 83.219, 'Andhra Pradesh'),
    'Warangal': (17.969, 79.594, 'Telangana'),
}


def _get(url, params):
    for attempt in (1, 2):  # one retry: free public API occasionally times out
        try:
            r = requests.get(url, params=params, timeout=8)
            r.raise_for_status()
            return r.json()
        except requests.RequestException:
            if attempt == 2:
                raise


def locate(city):
    key = city.strip().lower()
    for name, (lat, lon, state) in CITY_DB.items():
        if name.lower() == key:
            return {"name": name, "latitude": lat, "longitude": lon, "admin1": state}
    for q in ({"countryCode": "IN"}, {}):  # not in the built-in list: search India first, then worldwide
        g = _get("https://geocoding-api.open-meteo.com/v1/search", {"name": city, "count": 1, **q})
        if g.get("results"):
            return g["results"][0]
    raise ValueError(f"Could not find '{city}'. Pick a city from the list, or type your room's temperature and humidity instead.")


def live_weather(city):
    p = locate(city)
    w = _get("https://api.open-meteo.com/v1/forecast", {
        "latitude": p["latitude"], "longitude": p["longitude"], "current": "temperature_2m,relative_humidity_2m"})["current"]
    return {"place": f'{p["name"]}, {p.get("admin1") or p.get("country", "")}', "temp": w["temperature_2m"], "hum": w["relative_humidity_2m"], "time": w["time"]}


@app.route("/")
def home():
    groups = {}
    for k, p in PROFILES.items():
        groups.setdefault(p.get("category", "Other"), []).append((k, p))
    return render_template("index.html", groups=groups, envs=ENVS, cities=sorted(CITY_DB))


@app.route("/api/analyze", methods=["POST"])
def analyze():
    f = request.form
    plant, env = f.get("plant"), f.get("env")
    if plant not in PROFILES or env not in ENVS:
        return fail("Choose a plant and where it is kept.")
    mt, mh = f.get("temp", "").strip(), f.get("hum", "").strip()
    try:
        if mt or mh:  # manual indoor readings override live weather
            temp, hum = float(mt), float(mh)
            if not (-10 <= temp <= 60 and 0 <= hum <= 100):
                return fail("Enter a temperature from -10 to 60°C and humidity from 0 to 100%.")
            cond = {"source": "Your own room readings"}
        else:
            w = live_weather(f.get("city", "").strip() or "Pune")
            temp, hum = estimate_indoor(env, w["temp"], w["hum"])
            cond = {"source": f'Live weather in {w["place"]} ({w["temp"]}°C, {w["hum"]}% outdoors, {w["time"]}) adjusted for: {ENVS[env]["name"]}'}
    except ValueError as e:
        return fail("Enter both temperature and humidity as numbers, or leave both empty." if (mt or mh) else str(e))
    except (requests.RequestException, KeyError):
        return fail("Could not reach the weather service. Enter your room's temperature and humidity manually.", 502)

    leaf = None
    photo = request.files.get("photo")
    if photo and photo.filename:
        try:
            leaf = leaf_damage(photo.stream)
        except ValueError as e:
            return fail(str(e))
    result = analyse(plant, temp, hum, leaf["damage"] if leaf else None)
    result.update(conditions=cond, leaf=leaf)
    return jsonify(result)


if __name__ == "__main__":
    app.run(debug=True)
