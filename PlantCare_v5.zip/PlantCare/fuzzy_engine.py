"""Hierarchical Mamdani fuzzy system for indoor plant care.

Stage 1: Temperature x Humidity  -> Climate stress (9 rules)
Stage 2: Climate stress x Leaf damage (optional photo) -> Overall risk (9 rules)
Membership functions for temperature and humidity are generated from the
selected plant's profile, so the same reading means different things per plant.
"""
import json, os

PROFILES = json.load(open(os.path.join(os.path.dirname(__file__), "profiles.json"), encoding="utf-8"))

# Heuristic indoor estimate: weight on outdoor temp (rest pulled to 24 C), temp offset, humidity offset.
ENVS = {
    "vent": {"name": "Normal room (natural ventilation)", "w": .7, "t": 0, "h": 0},
    "window": {"name": "Sunny window sill", "w": .7, "t": 3, "h": -5},
    "ac": {"name": "Air-conditioned room", "w": .1, "t": 0, "h": -15},
    "bath": {"name": "Bathroom / kitchen", "w": .7, "t": 1, "h": 15},
    "balcony": {"name": "Sheltered balcony", "w": 1, "t": 0, "h": 0},
}


def estimate_indoor(env, out_t, out_h):
    e = ENVS[env]
    return round(e["w"] * out_t + (1 - e["w"]) * 24 + e["t"], 1), max(5, min(100, round(out_h + e["h"])))


def trapmf(x, a, b, c, d):
    if x < a or x > d:
        return 0.0
    if b <= x <= c:
        return 1.0
    return (x - a) / (b - a) if x < b else (d - x) / (d - c)


OUT = {"Low": (0, 0, 15, 40), "Moderate": (25, 50, 50, 75), "High": (60, 85, 100, 100)}
LEAF = {"Healthy": (0, 0, 8, 20), "Mild": (10, 25, 25, 45), "Severe": (30, 50, 100, 100)}
R1 = {("Cold", "Dry"): "High", ("Cold", "Ideal"): "High", ("Cold", "Humid"): "High",
      ("Ideal", "Dry"): "Moderate", ("Ideal", "Ideal"): "Low", ("Ideal", "Humid"): "Moderate",
      ("Hot", "Dry"): "High", ("Hot", "Ideal"): "High", ("Hot", "Humid"): "High"}
R2 = {("Low", "Healthy"): "Low", ("Low", "Mild"): "Moderate", ("Low", "Severe"): "High",
      ("Moderate", "Healthy"): "Moderate", ("Moderate", "Mild"): "Moderate", ("Moderate", "Severe"): "High",
      ("High", "Healthy"): "Moderate", ("High", "Mild"): "High", ("High", "Severe"): "High"}


def fuzzify(sets, x):
    return {k: trapmf(x, *v) for k, v in sets.items()}


def infer(inputs, rules, names, stage):
    """inputs: [(var_name, degrees)], rules: {(label,label): out}. AND=min, aggregation=max, centroid."""
    act, fired = {k: 0.0 for k in OUT}, []
    for labels, out in rules.items():
        s = min(d[l] for (_, d), l in zip(inputs, labels))
        if s > 0:
            act[out] = max(act[out], s)
            fired.append({"stage": stage, "strength": round(s, 3), "then": f"{names} is {out}",
                          "if": " AND ".join(f"{n} is {l}" for (n, _), l in zip(inputs, labels))})
    num = den = 0.0
    for i in range(201):
        x = i / 2
        mu = max(min(act[k], trapmf(x, *OUT[k])) for k in OUT)
        num += x * mu
        den += mu
    return (num / den if den else 0.0), fired


def level(score):
    return "Low" if score < 33 else "Moderate" if score < 67 else "High"


def _state(d):
    k = max(d, key=d.get)
    return k, d[k]


def explain(p, temp, hum, td, hd, ld, damage, climate, overall):
    """Plain-language reasons for the score, built from the plant's ideal ranges and the fuzzy memberships."""
    t1, t2 = p["temp"][1], p["temp"][2]
    h1, h2 = p["hum"][1], p["hum"][2]
    tk, hk = _state(td)[0], _state(hd)[0]
    if tk == "Cold":
        tt = f"{temp:.1f}°C is below the {t1}–{t2}°C this plant likes ({t1 - temp:.1f}°C too cold)"
    elif tk == "Hot":
        tt = f"{temp:.1f}°C is above the {t1}–{t2}°C this plant likes ({temp - t2:.1f}°C too hot)"
    else:
        tt = f"{temp:.1f}°C is inside the ideal {t1}–{t2}°C"
    if hk == "Dry":
        ht = f"{hum:.0f}% humidity is below the {h1}–{h2}% this plant likes (air too dry)"
    elif hk == "Humid":
        ht = f"{hum:.0f}% humidity is above the {h1}–{h2}% this plant likes (air too humid)"
    else:
        ht = f"{hum:.0f}% humidity is inside the ideal {h1}–{h2}%"
    factors = [
        {"name": "Temperature", "ok": tk == "Ideal", "text": tt},
        {"name": "Humidity", "ok": hk == "Ideal", "text": ht},
    ]
    if ld is not None:
        lk = _state(ld)[0]
        lt = {"Healthy": f"{damage:.0f}% of the leaf is yellow/brown, which is healthy",
              "Mild": f"{damage:.0f}% of the leaf is yellow/brown, which is mild damage",
              "Severe": f"{damage:.0f}% of the leaf is yellow/brown, which is severe damage"}[lk]
        factors.append({"name": "Leaf photo", "ok": lk == "Healthy", "text": lt})
    bad = [f["name"].lower() for f in factors if not f["ok"]]
    lvl = level(overall)
    if not bad:
        summary = f"Risk is {lvl.lower()} because every reading is inside this plant's comfort range."
    else:
        summary = (f"Risk is {lvl.lower()} mainly because of {' and '.join(bad)}. "
                   "Plants stress when conditions drift outside their comfort range, and the further out and the longer it lasts, "
                   "the more likely leaf damage, slowed growth or rot become.")
    return {"summary": summary, "factors": factors,
            "how": "Stage 1 fuzzy rules turn temperature and humidity into climate stress."
                   + (" Stage 2 combines that stress with leaf damage from the photo to give the overall risk." if ld is not None else " Without a photo, the overall risk equals the climate stress.")}


def analyse(plant, temp, hum, damage=None):
    p = PROFILES[plant]
    t0, t1, t2, t3 = p["temp"]
    h0, h1, h2, h3 = p["hum"]
    td = fuzzify({"Cold": (-50, -50, t0, t1), "Ideal": (t0, t1, t2, t3), "Hot": (t2, t3, 100, 100)}, temp)
    hd = fuzzify({"Dry": (0, 0, h0, h1), "Ideal": (h0, h1, h2, h3), "Humid": (h2, h3, 100, 100)}, hum)
    climate, rules = infer([("Temperature", td), ("Humidity", hd)], R1, "Climate stress", 1)
    degrees = {"Temperature": td, "Humidity": hd}
    overall = climate
    ld = None
    if damage is not None:
        ld = fuzzify(LEAF, damage)
        degrees["Leaf damage"] = ld
        overall, r2 = infer([("Climate stress", fuzzify(OUT, climate)), ("Leaf damage", ld)], R2, "Overall risk", 2)
        rules += r2

    c = {  # (degree, text) per condition; Ideal/Healthy need no action
        "Cold": (td["Cold"], f"Too cold for this plant (comfort starts at {t1}°C). Move it away from cold windows, draughts and AC vents, and water less: cool soil stays wet longer."),
        "Hot": (td["Hot"], f"Warmer than comfortable (up to {t2}°C). Keep it out of direct afternoon sun, improve ventilation and check the soil more often."),
        "Dry": (hd["Dry"], f"Air is drier than ideal (aim for {h1}–{h2}% humidity). Use a humidifier or pebble tray and keep it away from heaters and AC; misting only helps briefly."),
        "Humid": (hd["Humid"], f"Humidity is above ideal (aim for {h1}–{h2}%). Increase airflow with a fan or open window to reduce rot and fungus risk, and avoid wetting leaves late in the day."),
    }
    if ld:
        c["Mild"] = (ld["Mild"], "Some yellow or brown leaf area detected. Check watering (soggy soil tends to cause yellowing, dry soil or low humidity tends to brown the tips), light and pests; trim badly damaged leaves.")
        c["Severe"] = (ld["Severe"], "A lot of yellow or brown leaf area. Check roots and soil moisture first, look for pests, and fix the climate issues above before changing fertiliser.")
    care = [{"text": t, "urgency": "now" if d >= .6 else "soon", "d": d} for d, t in c.values() if d >= .3]
    care.sort(key=lambda x: -x["d"])
    if not care:
        care = [{"text": "Conditions look good. Keep your normal watering and avoid sudden changes in position or temperature.", "urgency": "soon", "d": 1}]
    return {
        "plant": p["name"], "temp": temp, "hum": hum, "degrees": degrees,
        "climate": {"score": round(climate, 1), "level": level(climate)},
        "overall": {"score": round(overall, 1), "level": level(overall)},
        "why": explain(p, temp, hum, td, hd, ld, damage, climate, overall),
        "rules": rules, "care": [{"text": x["text"], "urgency": x["urgency"]} for x in care], "notes": p["tips"],
    }
