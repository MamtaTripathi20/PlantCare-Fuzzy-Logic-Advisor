# PlantCare – Fuzzy Indoor Plant Care Advisor (Soft Computing mini project)

Pipeline: choose plant → choose where it is kept → live weather (Open-Meteo, no API key) → optional leaf photo → fuzzy analysis → risk score and care plan.

## Run
```
pip install -r requirements.txt
python app.py        # open http://127.0.0.1:5000
```
Needs internet only for live weather; entering your own room readings works offline.

## How it works
- **Plant profiles** (`profiles.json`): each plant has temperature and humidity ranges `[min, ideal-low, ideal-high, max]`. The fuzzy sets (Cold/Ideal/Hot, Dry/Ideal/Humid) are generated from these, so the same reading means different things for different plants.
- **Stage 1** Temperature x Humidity -> Climate stress (9 Mamdani rules).
- **Stage 2** Climate stress x Leaf damage -> Overall risk (9 rules). Skipped when no photo is given.
- Min for AND, max aggregation, centroid defuzzification. Hierarchical design avoids a 27-rule base.
- **Photo analysis** (`vision.py`): free and offline. Converts the image to HSV and measures the share of yellow/brown pixels among plant-coloured pixels. This "leaf damage %" is a fuzzy input.
- **Indoor estimate**: live weather is outdoor air, so it is blended toward 24°C and offset per location (window, AC, bathroom...). These offsets are heuristic assumptions; a manual reading overrides them.

## Limitations (say these in the viva)
- Plant ranges in `profiles.json` are approximate. Check them against a horticultural source and cite it.
- Photo analysis is colour-based: it cannot name diseases, and brown pots, soil, flowers or bad lighting can skew it. Use a plain background and daylight.
- It recommends care only; it does not control any heater, fan or humidifier.
- Weather data by Open-Meteo.com (CC BY 4.0, free for non-commercial use).

## What's new
- 71 plants including Indian flowers (marigold, rose, tuberose, champa...) and vegetables (tomato, chilli, okra, palak, methi...).
- City box suggests ~67 Indian cities; weather search looks in India first (Open-Meteo `countryCode=IN`), then worldwide.
- **Why this risk?** panel under the meter explains which readings are out of the plant's comfort range, with numbers.

## Data
- `data/plants.csv`: 71 plants with temperature/humidity ranges, light, watering and tips. **Edit this file, then run `python build_profiles.py`** to regenerate `profiles.json` (it validates the ranges).
- `data/readings.csv`: 7,100 **synthetic** labelled readings (100 per plant) made by `make_dataset.py`. The labels come from a smooth penalty function that is independent of the fuzzy rules. Replace the label columns with real expert ratings for a stronger result.
- `python evaluate.py` compares fuzzy vs plain if-else against these labels (MAE and Low/Moderate/High accuracy).
- The ranges were written from general horticultural guidance, not copied from one source. Verify against RHS / university extension sheets and cite them.

## Suggested additions for the soft computing project
1. **Genetic algorithm tuning** (best fit, easy to show): evolve the membership-function breakpoints and the 9+9 rule outputs to minimise MAE in `evaluate.py`. Show before/after.
2. **ANFIS or neural network baseline**: train an MLP (scikit-learn) on `readings.csv` and compare with fuzzy and if-else. Tabulate accuracy vs interpretability.
3. **Neuro-fuzzy leaf classifier**: replace the colour rule in `vision.py` with a small CNN or SVM trained on the PlantVillage / New Plant Diseases image datasets (Kaggle).
4. **Add light and soil moisture as fuzzy inputs** (`light` and `watering` columns already exist), so watering advice comes from fuzzy rules too.
5. **Sensitivity analysis**: vary membership-function shapes (triangular, Gaussian) and defuzzification (centroid, MOM, bisector) and report the effect.
6. **Time series**: use Open-Meteo's 7-day forecast to warn "frost or heat tomorrow, move the plant".
7. **Species ID** via the Pl@ntNet API (needs a key) so the plant is picked from a photo.
8. **Real data**: log your own plants' readings and health for 2-3 weeks to replace the synthetic dataset.
