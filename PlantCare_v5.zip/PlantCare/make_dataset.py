"""Generate data/readings.csv: SYNTHETIC labelled readings for evaluating the controllers.

Ground truth ("expert_stress") is a smooth penalty on how far temperature and humidity
fall outside the plant's ideal band, scaled by how wide the plant's tolerance is, plus
leaf damage and Gaussian noise. It is deliberately NOT the fuzzy rule base, so it works
as an independent yardstick. It is still synthetic: replace the label column with real
expert ratings or observed plant health for a stronger result.
"""
import csv, os
import numpy as np
from fuzzy_engine import PROFILES

HERE = os.path.dirname(os.path.abspath(__file__))
rng = np.random.default_rng(42)


def excess(x, lo, hi, tol):
    return max(lo - x, x - hi, 0) / tol


rows = []
for key, p in PROFILES.items():
    t0, t1, t2, t3 = p["temp"]; h0, h1, h2, h3 = p["hum"]
    for _ in range(100):
        # half the samples near the ideal band, half spread over the whole range
        if rng.random() < .5:
            t, h = rng.uniform(t1 - 3, t2 + 3), rng.uniform(h1 - 10, h2 + 10)
        else:
            t, h = rng.uniform(t0 - 6, t3 + 6), rng.uniform(5, 100)
        t, h = round(float(t), 1), round(float(np.clip(h, 0, 100)), 0)
        d = round(float(np.clip(rng.beta(1.2, 6) * 100, 0, 100)), 1)
        et = excess(t, t1, t2, (t1 - t0 + t3 - t2) / 2)
        eh = excess(h, h1, h2, (h1 - h0 + h3 - h2) / 2)
        climate = 100 * (1 - np.exp(-(1.1 * et ** 2 + 0.9 * eh ** 2) ** .5 * 1.3))
        risk = np.clip(.75 * climate + .25 * d + rng.normal(0, 4), 0, 100)
        climate_noisy = np.clip(climate + rng.normal(0, 4), 0, 100)
        lvl = lambda s: "Low" if s < 33 else "Moderate" if s < 67 else "High"
        rows.append([key, t, h, d, round(float(climate_noisy), 1), lvl(climate_noisy), round(float(risk), 1), lvl(risk)])

with open(os.path.join(HERE, "data", "readings.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["plant", "temp", "hum", "leaf_damage", "climate_stress", "climate_level", "overall_risk", "overall_level"])
    w.writerows(rows)
print(len(rows), "rows written")
