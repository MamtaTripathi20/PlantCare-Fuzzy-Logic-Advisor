"""Graphs for PlantCare: membership functions, control surface, fuzzy vs if-else comparison."""
import io
from functools import lru_cache

import numpy as np
from flask import Blueprint, Response, abort, jsonify, request
from matplotlib.figure import Figure

from crisp import crisp_risk
from fuzzy_engine import OUT, PROFILES, analyse, trapmf

bp = Blueprint("plots", __name__)
BG, FG, GRID, WHITE = "#121b27", "#c4d0da", "#263447", "#edf4f8"
COLS = ["#8bd88f", "#79aaff", "#ffbd75"]


def _style(ax, title, xlabel, ylabel=None):
    ax.set_facecolor("#0c141e")
    ax.set_title(title, color=WHITE, fontsize=10, loc="left")
    ax.set_xlabel(xlabel, color=FG, fontsize=8)
    if ylabel:
        ax.set_ylabel(ylabel, color=FG, fontsize=8)
    ax.tick_params(colors=FG, labelsize=8)
    for s in ax.spines.values():
        s.set_color(GRID)
    ax.grid(color=GRID, linewidth=.5)


def _png(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=110, facecolor=BG)
    return buf.getvalue()


def _mid(plant, key):
    p = PROFILES[plant][key]
    return (p[1] + p[2]) / 2


def _mark(ax, x):
    if x is not None:
        ax.axvline(x, color=WHITE, ls="--", lw=1)


@lru_cache(maxsize=64)
def mf_png(plant, t, h, d):
    tm, hm = _mid(plant, "temp"), _mid(plant, "hum")
    ts, hs, ds = np.arange(0, 45.01, .5), np.arange(0, 100.01, 1), np.arange(0, 100.01, 1)
    panels = [
        (ts, [analyse(plant, x, hm)["degrees"]["Temperature"] for x in ts], "Temperature sets", "Temperature (°C)", t),
        (hs, [analyse(plant, tm, x)["degrees"]["Humidity"] for x in hs], "Humidity sets", "Relative humidity (%)", h),
        (ds, [analyse(plant, tm, hm, damage=x)["degrees"]["Leaf damage"] for x in ds], "Leaf damage sets (from photo)", "Yellow/brown leaf area (%)", d),
        (hs, [{k: trapmf(x, *v) for k, v in OUT.items()} for x in hs], "Output sets (stress / risk)", "Score (0–100)", None),
    ]
    fig = Figure(figsize=(10, 6.2), facecolor=BG)
    for ax, (xs, rows, title, xlabel, mark) in zip(fig.subplots(2, 2).ravel(), panels):
        for c, name in zip(COLS, rows[0]):
            ax.plot(xs, [r[name] for r in rows], color=c, lw=2, label=name)
        _style(ax, title, xlabel, "Membership degree")
        _mark(ax, mark)
        ax.set_ylim(-.03, 1.05)
        ax.legend(fontsize=7, facecolor="#0c141e", edgecolor=GRID, labelcolor=FG, loc="center right")
    fig.suptitle(f"{PROFILES[plant]['name']}: membership functions", color=WHITE, fontsize=11, x=.02, ha="left")
    fig.tight_layout(rect=(0, 0, 1, .96))
    return _png(fig)


@lru_cache(maxsize=8)
def _grid(plant):
    ts, hs = np.linspace(0, 45, 37), np.linspace(0, 100, 26)
    z = np.array([[analyse(plant, t, h)["climate"]["score"] for t in ts] for h in hs])
    return (*np.meshgrid(ts, hs), z)


@lru_cache(maxsize=64)
def surface_png(plant, t, h):
    T, H, Z = _grid(plant)
    fig = Figure(figsize=(10, 4.4), facecolor=BG)
    a3 = fig.add_subplot(1, 2, 1, projection="3d")
    a3.plot_surface(T, H, Z, cmap="RdYlGn_r", vmin=0, vmax=100, linewidth=0, antialiased=True)
    a3.set_facecolor(BG)
    a3.view_init(elev=28, azim=-58)
    for a in (a3.xaxis, a3.yaxis, a3.zaxis):
        a.set_pane_color((.05, .08, .12, 1))
    a3.tick_params(colors=FG, labelsize=7)
    a3.set_xlabel("Temp (°C)", color=FG, fontsize=8)
    a3.set_ylabel("Humidity (%)", color=FG, fontsize=8)
    a3.set_zlabel("Climate stress", color=FG, fontsize=8)
    a3.set_title("Control surface", color=WHITE, fontsize=10, loc="left")
    ax = fig.add_subplot(1, 2, 2)
    cf = ax.contourf(T, H, Z, levels=np.linspace(0, 100, 11), cmap="RdYlGn_r")
    cb = fig.colorbar(cf, ax=ax)
    cb.ax.tick_params(colors=FG, labelsize=7)
    _style(ax, "Top view: green = low stress, red = high stress", "Temperature (°C)", "Relative humidity (%)")
    ax.grid(False)
    if t is not None and h is not None:
        s = analyse(plant, t, h)["climate"]["score"]
        ax.scatter([t], [h], s=70, color=WHITE, edgecolor="black", zorder=5, label=f"Your reading ({s:.0f})")
        a3.scatter([t], [h], [s], s=40, color=WHITE, edgecolor="black")
        ax.legend(fontsize=7, facecolor="#0c141e", edgecolor=GRID, labelcolor=FG, loc="upper right")
    fig.tight_layout()
    return _png(fig)


@lru_cache(maxsize=64)
def compare_png(plant, t, h):
    tm, hm = _mid(plant, "temp"), _mid(plant, "hum")
    ts, hs = np.arange(0, 45.01, .5), np.arange(0, 100.01, 1)
    fig = Figure(figsize=(10, 3.8), facecolor=BG)
    a1, a2 = fig.subplots(1, 2)
    for ax, xs, fz, cr, title, xl, mark in [
        (a1, ts, lambda x: analyse(plant, x, hm)["climate"]["score"], lambda x: crisp_risk(plant, x, hm)[0],
         f"Temperature sweep (humidity held at {hm:.0f}%)", "Temperature (°C)", t),
        (a2, hs, lambda x: analyse(plant, tm, x)["climate"]["score"], lambda x: crisp_risk(plant, tm, x)[0],
         f"Humidity sweep (temperature held at {tm:.1f}°C)", "Relative humidity (%)", h)]:
        ax.plot(xs, [fz(x) for x in xs], color=COLS[0], lw=2.2, label="Fuzzy (Mamdani)")
        ax.plot(xs, [cr(x) for x in xs], color=COLS[2], lw=2, drawstyle="steps-post", label="Plain if-else")
        _style(ax, title, xl, "Climate stress (0–100)")
        _mark(ax, mark)
        ax.set_ylim(0, 100)
        ax.legend(fontsize=7, facecolor="#0c141e", edgecolor=GRID, labelcolor=FG, loc="center")
    fig.tight_layout()
    return _png(fig)


@lru_cache(maxsize=16)
def sweep_metrics(plant):
    hm, ts = _mid(plant, "hum"), np.arange(0, 45.01, .5)
    f = [analyse(plant, t, hm)["climate"]["score"] for t in ts]
    c = [crisp_risk(plant, t, hm)[0] for t in ts]
    return {"fuzzy": round(float(np.abs(np.diff(f)).max()), 1), "crisp": round(float(np.abs(np.diff(c)).max()), 1)}


def _args():
    f = lambda k: (None if request.args.get(k, type=float) is None else round(request.args.get(k, type=float), 1))
    return f("t"), f("h"), f("d")


@bp.route("/plots/<plant>/<kind>.png")
def plot(plant, kind):
    if plant not in PROFILES or kind not in ("mf", "surface", "compare"):
        abort(404)
    t, h, d = _args()
    png = {"mf": lambda: mf_png(plant, t, h, d), "surface": lambda: surface_png(plant, t, h),
           "compare": lambda: compare_png(plant, t, h)}[kind]()
    return Response(png, mimetype="image/png")


@bp.route("/api/compare")
def compare():
    plant = request.args.get("plant")
    if plant not in PROFILES:
        abort(404)
    out = {"max_step": sweep_metrics(plant)}
    t, h, _ = _args()
    if t is not None and h is not None:
        s, lvl = crisp_risk(plant, t, h)
        out["reading"] = {"fuzzy": analyse(plant, t, h)["climate"], "crisp": {"score": s, "level": lvl}}
    return jsonify(out)
