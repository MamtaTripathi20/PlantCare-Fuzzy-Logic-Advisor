"""Compare fuzzy vs plain if-else against data/readings.csv (climate stress, Stage 1)
and the full two-stage fuzzy system (overall risk). Run: python evaluate.py"""
import csv, os
import numpy as np
from fuzzy_engine import analyse
from crisp import crisp_risk

HERE = os.path.dirname(os.path.abspath(__file__))
rows = list(csv.DictReader(open(os.path.join(HERE, "data", "readings.csv"), encoding="utf-8")))
y = np.array([float(r["climate_stress"]) for r in rows])
yl = np.array([r["climate_level"] for r in rows])
yo = np.array([float(r["overall_risk"]) for r in rows])
ylo = np.array([r["overall_level"] for r in rows])

fz, fl, cr, cl, ov, ol = [], [], [], [], [], []
for r in rows:
    p, t, h, d = r["plant"], float(r["temp"]), float(r["hum"]), float(r["leaf_damage"])
    a = analyse(p, t, h)
    fz.append(a["climate"]["score"]); fl.append(a["climate"]["level"])
    s, l = crisp_risk(p, t, h)
    cr.append(s); cl.append(l)
    b = analyse(p, t, h, d)
    ov.append(b["overall"]["score"]); ol.append(b["overall"]["level"])
fz, cr, ov = map(np.array, (fz, cr, ov))
fl, cl, ol = map(np.array, (fl, cl, ol))

def line(name, pred, lab, truth, truthl):
    print(f"{name:34s} MAE {np.abs(pred - truth).mean():5.1f}   level accuracy {100 * (lab == truthl).mean():5.1f}%")

print(f"{len(rows)} readings, {len(set(r['plant'] for r in rows))} plants\n")
line("Climate stress: fuzzy (Stage 1)", fz, fl, y, yl)
line("Climate stress: plain if-else", cr, cl, y, yl)
line("Overall risk: fuzzy (Stage 1+2)", ov, ol, yo, ylo)
