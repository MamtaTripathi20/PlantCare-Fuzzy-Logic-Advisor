"""Build profiles.json from data/plants.csv (the editable source of truth).

Usage: python build_profiles.py
Checks that each range is ordered min < ideal-low <= ideal-high < max.
"""
import csv, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    out, bad = {}, []
    with open(os.path.join(HERE, "data", "plants.csv"), encoding="utf-8", newline="") as f:
        for r in csv.DictReader(f):
            t = [float(r[k]) for k in ("temp_min", "temp_ideal_low", "temp_ideal_high", "temp_max")]
            h = [float(r[k]) for k in ("hum_min", "hum_ideal_low", "hum_ideal_high", "hum_max")]
            for label, v, lo, hi in (("temp", t, -10, 60), ("hum", h, 0, 100)):
                if not (v[0] < v[1] <= v[2] < v[3]) or v[0] < lo or v[3] > hi:
                    bad.append(f"{r['key']}: bad {label} range {v}")
            out[r["key"]] = {"name": r["name"], "category": r["category"],
                             "temp": [int(x) for x in t], "hum": [int(x) for x in h],
                             "light": r["light"], "watering": r["watering"],
                             "tips": [r["tip1"], r["tip2"]]}
    if bad:
        sys.exit("\n".join(bad))
    with open(os.path.join(HERE, "profiles.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1, ensure_ascii=False)
    print(f"Wrote profiles.json with {len(out)} plants")


if __name__ == "__main__":
    main()
